from typing import Any
from sksurv.datasets import load_whas500, load_gbsg2, load_aids
import pandas as pd
import numpy as np
from pandas import DataFrame
from sklearn.model_selection import train_test_split
from synthcity.plugins.core.dataloader import SurvivalAnalysisDataLoader
from synthcity.plugins import Plugins
from synthcity.plugins.core.constraints import Constraints
from synthcity.metrics import eval_statistical


def generate_synthetic_data(original_data: DataFrame, num_samples: int, **kwargs: Any):
    rules = [(column, 'in', original_data[column].unique().tolist()) for column in original_data.select_dtypes(include=['category'])]
    rules = rules + [(column, 'dtype', original_data[column].dtype.name) for column in original_data.select_dtypes(exclude=['category'])]
    constraints = Constraints(rules=rules)
    syn_data_loader = SurvivalAnalysisDataLoader(
        original_data,
        target_column="censor",
        time_to_event_column="time",
        constrains=constraints
    )
    syn_gen = Plugins().get("survival_gan", **kwargs)
    syn_gen.fit(syn_data_loader)
    syn_data = syn_gen.generate(count=num_samples)
    df_syn = syn_data.raw()
    return syn_data_loader, df_syn


# Returns the censor statistics according to a given timeframe
def censored_percentage(syn_df: DataFrame, time: int):
    censored = (syn_df[(syn_df['time'] < time) & (syn_df['censor'] == False)].shape[0])/syn_df.shape[0]
    return censored*100


# returns the earliest timeframe with above 80% censoring (or as close as possible)
def determine_censor_time(df: DataFrame):
    time = 0
    top_percent = 0
    for i in np.arange(df['time'].min(), df['time'].max(), df['time'].max() / 20):
        censored = censored_percentage(df, i)
        if censored > top_percent:
            top_percent = censored
            time = i
        if top_percent >= 80:
            break
    return time, top_percent


# transform y of (censor, time) to a binary labels vector
def classification_transform(y: DataFrame, target_label="event"):
    y_classification = pd.DataFrame(columns=[target_label])
    y_classification[target_label] = np.logical_not(y['censor'])
    return y_classification


def data_evaluation(data1, data2):
    for col in data2.columns:
        data1[col] = data1[col].astype(int)
        data2[col] = data2[col].astype(int)
    eval_score = (f"Data evaluation:\nInverseKLDivergence:"
                  f" {eval_statistical.InverseKLDivergence().evaluate(data1, data2)}\n"
                  f"KolmogorovSmirnovTest: {eval_statistical.KolmogorovSmirnovTest().evaluate(data1, data2)}\n"
                  f"ChiSquaredTest: {eval_statistical.ChiSquaredTest().evaluate(data1, data2)}\n"
                  f"MaximumMeanDiscrepancy: {eval_statistical.MaximumMeanDiscrepancy().evaluate(data1, data2)}")
    return eval_score


def split_c_uc(df, time):
    df_censored = df[(df['time'] < time) & (df['censor'] == False)]
    df_uncensored = df[~((df['time'] < time) & (df['censor'] == False))]
    return df_censored, df_uncensored


# returns a dict of all the datasets required for an experiment, by a given timeframe
def create_datasets(df, time: int):
    df_censored, df_uncensored = split_c_uc(df, time)
    X = df_uncensored.drop(labels=['censor', 'time'], axis=1)
    y = df_uncensored[['censor', 'time']]
    X_train_uc, X_test_uc, y_train_uc, y_test_uc = train_test_split(X, y, test_size=0.55, train_size=0.45, random_state=42)

    X_train_c = df_censored.drop(labels=['censor', 'time'], axis=1)
    y_train_c = df_censored[['censor', 'time']]

    X_train = pd.concat([X_train_c, X_train_uc])
    y_train = pd.concat([y_train_c, y_train_uc])

    uncensored_y_train = classification_transform(y_train_uc)
    uncensored_y_test = classification_transform(y_test_uc)
    datasets_dict = {'uncensored': {'X_train': X_train_uc, 'y_train': uncensored_y_train,
                                    'y_test': uncensored_y_test},
                     'censored': {'X_train': X_train, 'y_train': y_train},
                     'test': {'X': X_test_uc, 'y': y_test_uc}}
    print(f'test size: {X_test_uc.shape[0]}')
    return datasets_dict


# returns a dataframe that uses a given fraction of its censored samples (frac between 0 and 1), for a given timeframe
def use_censored_samples(X, y, frac, time: int):
    df = pd.merge(X.drop(labels=['censor', 'time'], axis=1, errors='ignore'), y, left_index=True, right_index=True, how='outer')
    df_censored = df[(df['time'] < time) & (df['censor'] == False)]
    df_uncensored = df[~((df['time'] < time) & (df['censor'] == False))]
    df = get_df_with_censoring_ratio(df_censored, df_uncensored, frac)
    num_censored = df[(df['time'] < time) & (df['censor'] == False)].shape[0]
    censored_percent = num_censored/df.shape[0]
    print(f'censored percentage of train samples: {censored_percent*100}%, {num_censored} samples')
    X = df.drop(labels=['censor', 'time'], axis=1)
    y = df[['censor', 'time']]
    return X, y


def get_df_with_censoring_ratio(df_censored, df_uncensored, r):
    # finding the frac of the censored data
    amount = r*df_uncensored.shape[0]/(1-r)
    return pd.concat([df_censored.sample(int(amount)), df_uncensored])


def load_prepare_whas500_dataset():
    X, y = load_whas500()
    orig_data = pd.merge(pd.DataFrame(X), pd.DataFrame(y), left_index=True, right_index=True, how='outer')
    orig_data.dropna(inplace=True)

    orig_data.rename(columns={'fstat': 'censor', 'lenfol': 'time'}, inplace=True)
    orig_data['age'] = orig_data['age'].astype(int)
    orig_data['diasbp'] = orig_data['diasbp'].astype(int)
    orig_data['hr'] = orig_data['hr'].astype(int)
    orig_data['los'] = orig_data['los'].astype(int)
    orig_data['time'] = orig_data['time'].astype(int)
    orig_data['sysbp'] = orig_data['sysbp'].astype(int)
    orig_data = orig_data[orig_data['time'] > 0]

    return orig_data


def load_prepare_aids_dataset():
    X, y = load_aids('aids')
    orig_data = pd.merge(pd.DataFrame(X), pd.DataFrame(y), left_index=True, right_index=True, how='outer')
    orig_data.dropna(inplace=True)

    orig_data.rename(columns={'fstat': 'censor', 'lenfol': 'time'}, inplace=True)
    orig_data['age'] = orig_data['age'].astype(int)
    orig_data['time'] = orig_data['time'].astype(int)
    orig_data['priorzdv'] = orig_data['priorzdv'].astype(int)
    orig_data = orig_data[orig_data['time'] > 0]

    return orig_data
